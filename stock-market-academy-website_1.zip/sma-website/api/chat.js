// ============================================================
// Stock Market Academy — AI Tutor Backend
// Uses: Google Gemini 1.5 Flash (FREE — 1,500 req/day)
// Get your free key: https://aistudio.google.com
// Set env variable: GEMINI_API_KEY in Vercel dashboard
// ============================================================

export default async function handler(req, res) {
  // Allow frontend to call this route
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const GEMINI_KEY = process.env.GEMINI_API_KEY;
  if (!GEMINI_KEY) {
    return res.status(500).json({
      error: 'GEMINI_API_KEY not set. Add it in your Vercel dashboard under Settings → Environment Variables.'
    });
  }

  try {
    const { messages = [] } = req.body;

    // Convert our chat history format to Gemini's format
    // Gemini uses "user"/"model" instead of "user"/"assistant"
    const geminiContents = messages.map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const systemInstruction = `You are Stock Market Academy AI Tutor — an expert stock market and trading educator focused on Indian markets. You specialise in:

MARKETS: NSE, BSE, Nifty 50, Sensex, SEBI regulations, Indian brokers (Zerodha, Groww, Upstox, Angel One)

TECHNICAL ANALYSIS: All candlestick patterns (Hammer, Doji, Engulfing, Morning/Evening Star, Shooting Star, Three White Soldiers, Three Black Crows, Hanging Man, Tweezer Tops/Bottoms), RSI, MACD, Bollinger Bands, Fibonacci retracements, Moving Averages (SMA/EMA), Support & Resistance zones, Volume analysis, VWAP, Pivot Points

TRADING STRATEGIES: Trend following, breakout trading, pullback/retest entries, swing trading (2-14 days), momentum/intraday, value investing, Jason Graystone's Opportunity Confluence method

FUNDAMENTAL ANALYSIS: P/E ratio, EPS growth, ROE, Debt-to-Equity, Free Cash Flow, PEG ratio, promoter holding %, Screener.in usage, reading annual reports

INDIAN TAXATION (FY 2025-26): LTCG 12.5% with ₹1.25 lakh annual exemption, STCG 20%, STT rates (0.1% delivery, 0.025% intraday), F&O as speculative/business income, ITR-2 vs ITR-3 selection, LTCG harvesting strategy, carry-forward of losses

RISK MANAGEMENT: 1-2% per trade rule, position sizing formula (Risk ÷ Stop distance = Shares), stop-loss placement, risk:reward ratios (minimum 1:2), trading psychology, journal keeping, backtesting on TradingView Bar Replay

PORTFOLIO: Diversification across sectors (IT/Finance/Pharma/FMCG/Auto/Energy), large/mid/small-cap allocation, SIP investing, rupee cost averaging, rebalancing schedule, index fund investing

RULES:
- Give clear, educational, concise answers with line breaks for readability
- Use real Indian examples: Reliance, TCS, HDFC Bank, Nifty 50, Infosys, Asian Paints
- Always use ₹ (rupee) for amounts, not $ or USD
- Format key terms with **bold**
- Never give specific buy/sell calls on real stocks
- For any investment advice, end with: "Educational only — not financial advice. Consult a SEBI-registered advisor."
- If asked something outside finance/trading, politely redirect to stock market topics`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: {
            parts: [{ text: systemInstruction }]
          },
          contents: geminiContents,
          generationConfig: {
            maxOutputTokens: 1000,
            temperature: 0.7,
            topP: 0.9
          },
          safetySettings: [
            { category: 'HARM_CATEGORY_HARASSMENT',        threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_HATE_SPEECH',       threshold: 'BLOCK_ONLY_HIGH' },
            { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_ONLY_HIGH' }
          ]
        })
      }
    );

    if (!response.ok) {
      const errBody = await response.json().catch(() => ({}));
      const msg = errBody?.error?.message || `Gemini API error: HTTP ${response.status}`;
      // Handle quota exceeded gracefully
      if (response.status === 429) {
        return res.status(429).json({ error: 'Free tier quota reached. Wait a minute and try again (Gemini Flash allows 15 requests/minute).' });
      }
      return res.status(response.status).json({ error: msg });
    }

    const data = await response.json();
    const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!reply) {
      return res.status(500).json({ error: 'Gemini returned an empty response. Please try again.' });
    }

    return res.json({ reply });

  } catch (err) {
    console.error('[SMA Chat Error]', err);
    return res.status(500).json({ error: `Server error: ${err.message}` });
  }
}
